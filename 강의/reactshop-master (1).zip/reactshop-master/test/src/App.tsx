import React from 'react';
import TodoContainer from './TodoContainer';

function App() {
  return (
    <TodoContainer />
  );
}

export default App;
