export default [
  {
    id: 3,
    title: "Flowey",
    content: "only 5 inches",
    price: 120000,
  },
  {
    id: 4,
    title: "Baby shoes",
    content: "for less than 6",
    price: 120000,
  },
  {
    id: 5,
    title: "Red Herring",
    content: "Born in France",
    price: 120000,
  },
  {
    id: 6,
    title: "프로스텍스",
    content: "only 5 inches",
    price: 120000,
  },
  {
    id: 7,
    title: "아티스",
    content: "for less than 6",
    price: 120000,
  },
  {
    id: 8,
    title: "리복",
    content: "Born in France",
    price: 120000,
  },
];
