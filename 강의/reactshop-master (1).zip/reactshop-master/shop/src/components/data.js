export default [
  {
    id: 0,
    title: "아디다스",
    content: "프랑스산",
    price: 12000,
  },
  {
    id: 1,
    title: "나이키",
    content: "미국제",
    price: 11000,
  },
  {
    id: 2,
    title: "에르메스",
    content: "이탈리아산",
    price: 13000,
  },
  {
    id: 3,
    title: "Flowey",
    content: "only 5 inches",
    price: 120000,
  },
  {
    id: 4,
    title: "Baby shoes",
    content: "for less than 6",
    price: 120000,
  },
  {
    id: 5,
    title: "Red Herring",
    content: "Born in France",
    price: 120000,
  },
  {
    id: 6,
    title: "프로스텍스",
    content: "only 5 inches",
    price: 120000,
  },
  {
    id: 7,
    title: "아티스",
    content: "for less than 6",
    price: 120000,
  },
  {
    id: 8,
    title: "리복",
    content: "Born in France",
    price: 120000,
  },
];
